#!/usr/bin/env python3
from cli import get_parser
#import json


def main():
    parser=get_parser()
    

#def get_data(file_path: str):
#    file_as_dict = json.load(open(file_path))
#    return file_as_dict


#def sort_data(input_file):
#    return dict(sorted(input_file()))


#def generate_diff(first_file, second_file):
#    return

if __name__ == '__main__':
        main()


